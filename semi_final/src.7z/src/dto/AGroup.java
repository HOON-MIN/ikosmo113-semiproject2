/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author jinah
 */
public class AGroup {

    private int groupnum, ghobby;
    private String gname, gloc, ginfo, gdate;

    public int getGroupnum() {
        return groupnum;
    }

    public void setGroupnum(int groupnum) {
        this.groupnum = groupnum;
    }

    public int getGhobby() {
        return ghobby;
    }

    public void setGhobby(int ghobby) {
        this.ghobby = ghobby;
    }

    public String getGname() {
        return gname;
    }

    public void setGname(String gname) {
        this.gname = gname;
    }

    public String getGloc() {
        return gloc;
    }

    public void setGloc(String gloc) {
        this.gloc = gloc;
    }

    public String getGinfo() {
        return ginfo;
    }

    public void setGinfo(String ginfo) {
        this.ginfo = ginfo;
    }

    public String getGdate() {
        return gdate;
    }

    public void setGdate(String gdate) {
        this.gdate = gdate;
    }


}
