/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author jinah
 */
public class AHost {
    // hnum = pk
    // mnum = uq
    private int hnum, mnum;

    public int getHnum() {
        return hnum;
    }

    public void setHnum(int hnum) {
        this.hnum = hnum;
    }

    public int getMnum() {
        return mnum;
    }

    public void setMnum(int mnum) {
        this.mnum = mnum;
    }
    
    
}
