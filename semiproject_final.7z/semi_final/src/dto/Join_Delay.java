package dto;

public class Join_Delay {
    private int gdnum, membernum,groupnum;
    private String ddate;

    public int getGdnum() {
        return gdnum;
    }

    public void setGdnum(int gdnum) {
        this.gdnum = gdnum;
    }

    public int getMembernum() {
        return membernum;
    }

    public void setMembernum(int membernum) {
        this.membernum = membernum;
    }

    public int getGroupnum() {
        return groupnum;
    }

    public void setGroupnum(int groupnum) {
        this.groupnum = groupnum;
    }

    public String getDdate() {
        return ddate;
    }

    public void setDdate(String ddate) {
        this.ddate = ddate;
    }
    
}
