/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author dmdm2
 */
public class Hobby {
    private String Hname;
    private int hobbynum;

    public String getHname() {
        return Hname;
    }

    public void setHname(String Hname) {
        this.Hname = Hname;
    }

    public int getHobbynum() {
        return hobbynum;
    }

    public void setHobbynum(int hobbynum) {
        this.hobbynum = hobbynum;
    }
    
}
